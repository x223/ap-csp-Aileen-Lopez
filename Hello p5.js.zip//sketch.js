var xpos = 50;
var ypos= 50;
var xdir = 10;
var ydir = 1;

function setup() { 
  createCanvas(400, 400);
} 

function draw() { 
  background(500, 500);
	noStroke()
	ellipse(xpos, ypos, 50, 50);
	triangle(0, windowHeight, xpos, ypos, windowWidth, windowHight);
	xpos = xpos + xdir;
	if (xpos >= windowWidth, xpos<= 25) (
		xdir = xdir *-1;
		}
}