var strokecolor = 'purple'
var key = 'black'


function setup() { 
  createCanvas(900, 900);
} 

function draw(){ 
	
		if (mouseIsPressed) {
			stroke(strokecolor)
    	line(pmouseX, pmouseY, mouseX, mouseY);
  }
}

function keyTyped() {
  if (key === 'b') {
    strokeColor = 'purple';
  } else if (key === 'p') {
    strokeColor = '#E32173';
    weight = 10;
  }

	
}